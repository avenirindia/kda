<?php
define("BASE_PATH", realpath(dirname(__DIR__)));
