</div> <!-- container end -->

<footer class="text-center mt-4 mb-2">
    <hr>
    <p class="mb-0">© <?php echo date("Y"); ?> KDA Microfinance ERP | Developed by Your Company</p>
</footer>

<script src="../../assets/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../assets/js/custom.js"></script> <!-- যদি কাস্টম JS থাকে -->

</body>
</html>
